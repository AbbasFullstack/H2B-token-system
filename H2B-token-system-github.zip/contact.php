<?php
session_start();
require_once 'db.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name'] ?? '');
    $uid = $conn->real_escape_string($_POST['uid'] ?? '');
    $msg = $conn->real_escape_string($_POST['message'] ?? '');
    
    if (!empty($name) && !empty($uid) && !empty($msg)) {
        // Save to contact_messages table (create if not exists)
        $create = "CREATE TABLE IF NOT EXISTS contact_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100),
            uid VARCHAR(10),
            message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $conn->query($create);
        
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, uid, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $uid, $msg);
        
        if ($stmt->execute()) {
            $message = "✅ Message sent! Main jald reply dunga.";
            $message_type = "success";
        } else {
            $message = "❌ Error sending message. Try again!";
            $message_type = "error";
        }
        $stmt->close();
    } else {
        $message = "❌ Please fill all fields!";
        $message_type = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - H2B Abbas</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%);
            font-family: 'Poppins', 'Segoe UI', sans-serif;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .nav {
            background: rgba(0,0,0,0.8);
            border-radius: 50px;
            padding: 15px 25px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            border: 1px solid #00ff41;
        }
        .logo {
            color: #00ff41;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: 0.3s;
        }
        .nav-links a:hover {
            color: #00ff41;
        }
        .card {
            background: rgba(0,0,0,0.7);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #00ff41;
        }
        .card h2 {
            color: #00ff41;
            margin-bottom: 20px;
            border-left: 3px solid #00ff41;
            padding-left: 15px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            color: #00ff41;
            display: block;
            margin-bottom: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            background: #0f0f1a;
            border: 1px solid #333;
            border-radius: 10px;
            color: white;
            font-size: 1rem;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: #00ff41;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #00ff41;
            color: #000;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1rem;
        }
        button:hover {
            background: #00cc33;
        }
        .message {
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .success {
            background: #00ff4122;
            border: 1px solid #00ff41;
            color: #00ff41;
        }
        .error {
            background: #ff333322;
            border: 1px solid #ff3333;
            color: #ff6666;
        }
        .social-links {
            margin-top: 20px;
            text-align: center;
        }
        .social-links a {
            color: #00ff41;
            text-decoration: none;
            margin: 0 10px;
        }
        .footer {
            text-align: center;
            color: #666;
            margin-top: 30px;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="nav">
        <div class="logo">🔥 H2B ABBAS</div>
        <div class="nav-links">
            <a href="index.php">🏠 Home</a>
            <a href="about.php">📖 About</a>
            <a href="contact.php">📞 Contact</a>
        </div>
    </div>

    <div class="card">
        <h2>📞 Contact Me</h2>
        
        <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Your Name (Freefire ID)</label>
                <input type="text" name="name" required placeholder="e.g., H2B Blaster">
            </div>
            <div class="form-group">
                <label>Freefire UID</label>
                <input type="text" name="uid" required placeholder="9791354456" maxlength="10">
            </div>
            <div class="form-group">
                <label>Message</label>
                <textarea name="message" rows="5" required placeholder="Type your message here..."></textarea>
            </div>
            <button type="submit">Send Message</button>
        </form>
        
        <div class="social-links">
            <p style="color:#888; margin-top: 20px;">🔹 Connect with me 🔹</p>
            <p>WhatsApp / Telegram: <span style="color:#00ff41;">Whatsapp: +923088361404 / Abbas develope</span></p>
        </div>
    </div>
    
    <div class="footer">
        <p>© 2026 H2B Gaming | Freefire Pro Player & Developer</p>
    </div>
</div>
</body>
</html>