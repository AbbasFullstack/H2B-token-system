<?php
session_start();
require_once 'db.php';

// Your 10 Adsterra Smartlinks
$links = [
    'https://www.effectivecpmnetwork.com/pt97w3wut?key=e021d1aa31fa4a51f5ac28e8dbf4ebec',
    'https://www.effectivecpmnetwork.com/fvwxhatu9a?key=bc0981ca36efd3b2fa776b1957eff7a8',
    'https://www.effectivecpmnetwork.com/hapvm5jr?key=6b268393792152f670c251384a070aa1',
    'https://www.effectivecpmnetwork.com/sau1bji3?key=cdeb6855155a16796a117f353dd3b3a6',
    'https://www.effectivecpmnetwork.com/ai6xtnqc?key=ef3000f4b525d25ee72a97503bd5833e',
    'https://www.effectivecpmnetwork.com/tzvyq1v3p?key=1a54baee6335b944063ba11c53746364',
    'https://www.effectivecpmnetwork.com/submca35?key=ccdae4589fc2a22ff8c485ce323ec1e6',
    'https://www.effectivecpmnetwork.com/rvvn4fvpxk?key=16620d12a3623b580f4fb36522cd4cc8',
    'https://www.effectivecpmnetwork.com/sq17bff2b?key=772cc8f27393c803c3dd1d9bbb74a8fc',
    'https://www.effectivecpmnetwork.com/syy1ykaq6v?key=5e807d746e470e51f2c2b5f36818ca08'
];

$PPD_LINK = 'https://www.file-upload.org/iw8qent4z2bf'; // Update with your link

// Get UID from URL
$uid = isset($_GET['uid']) ? preg_replace('/[^0-9]/', '', $_GET['uid']) : '';

if (empty($uid)) {
    die("No UID provided. <a href='index.php'>Go back to home page.</a>");
}

// Initialize session if not set
if (!isset($_SESSION['click_step_' . $uid])) {
    $_SESSION['click_step_' . $uid] = 0;
}

$current_step = $_SESSION['click_step_' . $uid];

// If already completed 10 clicks, redirect to PPD
if ($current_step >= 10) {
    header("Location: $PPD_LINK");
    exit;
}

// Handle step parameter
if (isset($_GET['step'])) {
    $step = (int)$_GET['step'];
    if ($step > $current_step && $step <= 10) {
        $_SESSION['click_step_' . $uid] = $step;
        $current_step = $step;
    }
}

// If step is less than 10, show the click page
if ($current_step < 10) {
    $next_step = $current_step + 1;
    $next_link = "click_system.php?step=$next_step&uid=" . urlencode($uid);
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Step <?php echo $next_step; ?>/10 - H2B Abbas</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            *{margin:0;padding:0;box-sizing:border-box;}
            body{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 100%);font-family:'Poppins',monospace;min-height:100vh;padding:20px;}
            .container{max-width:500px;margin:0 auto;}
            .card{background:rgba(0,0,0,0.75);backdrop-filter:blur(10px);border-radius:30px;padding:30px 25px;border:2px solid #00ff41;box-shadow:0 0 30px rgba(0,255,65,0.3);margin-bottom:20px;text-align:center;}
            h2{color:#00ff41;margin-bottom:20px;}
            .progress{background:#333;border-radius:20px;height:20px;margin:20px 0;}
            .progress-bar{background:#00ff41;width:<?php echo ($current_step*10); ?>%;height:20px;border-radius:20px;}
            .click-btn{background:#ff5500;color:white;padding:15px 30px;font-size:20px;border:none;border-radius:50px;cursor:pointer;margin:20px 0;display:inline-block;text-decoration:none;}
            .click-btn:hover{background:#ff7700;}
            .ad-container{margin:20px 0;padding:10px;background:#111;border-radius:10px;}
            .note{font-size:12px;color:#aaa;}
            .footer{margin-top:25px;text-align:center;color:#666;font-size:0.7rem;}
        </style>
    </head>
    <body>
    <div class="container">
        <div class="card">
            <h2>🔓 Step <?php echo $next_step; ?> of 10</h2>
            <div class="progress"><div class="progress-bar"></div></div>
            <p>Click the button below to continue and get your token.</p>
            
            <div class="ad-container">
                <script>
                    atOptions = {
                        'key' : '60af30741893b080cce19659c17e0662',
                        'format' : 'iframe',
                        'height' : 250,
                        'width' : 300,
                        'params' : {}
                    };
                </script>
                <script src="https://www.highperformanceformat.com/60af30741893b080cce19659c17e0662/invoke.js"></script>
            </div>
            
            <a href="<?php echo $links[$next_step-1]; ?>" target="_blank" class="click-btn" onclick="setTimeout(function(){window.location='<?php echo $next_link; ?>';}, 3000);">
                👉 CLICK TO PROCEED 👈
            </a>
            
            <p class="note">Click the button, wait 3 seconds, next page will load automatically.</p>
        </div>
        <div class="footer">
            <p>© 2026 H2B Gaming | 10 Clicks = 1 Download = 1 Game</p>
        </div>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// If we reach here, redirect to PPD
header("Location: $PPD_LINK");
exit;
?>