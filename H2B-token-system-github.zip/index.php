<?php
session_start();
require_once 'db.php';

// Get today's player count
$today = date('Y-m-d');
$count_today = 0;
$result = $conn->query("SELECT COUNT(DISTINCT uid) as cnt FROM daily_limit WHERE last_download_date = '$today'");
if ($result && $row = $result->fetch_assoc()) {
    $count_today = $row['cnt'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes, viewport-fit=cover">
    
    <!-- ========== FAVICON ========== -->
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
    <!-- ========== SEO / GOOGLE META TAGS ========== -->
    <title>H2B Abbas | Freefire Pro Player | Get Token & Play</title>
    <meta name="description" content="Play Freefire with H2B Abbas. Complete 10 clicks, download token file, and get your unique token to play with pro player Abbas. 500+ players waiting!">
    <meta name="keywords" content="H2B Abbas, Freefire, Freefire token, play with pro, Freefire player, H2B gaming">
    <meta name="author" content="H2B Abbas">
    <meta name="robots" content="index, follow">
    
    <!-- ========== OPEN GRAPH (SOCIAL MEDIA) ========== -->
    <meta property="og:title" content="H2B Abbas | Freefire Pro Player">
    <meta property="og:description" content="Get your token and play Freefire with pro player H2B Abbas. Complete 10 clicks, download file, get unique token!">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://h2b.gamer.free">
    <meta property="og:image" content="https://h2b.gamer.free/favicon.ico">
    
    <!-- ========== THEME COLOR (BROWSER TAB) ========== -->
    <meta name="theme-color" content="#ff0000">
    <meta name="msapplication-TileColor" content="#ff0000">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #0a0a0a;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Poppins', sans-serif;
            min-height: 100vh;
            padding: 12px;
            padding-bottom: 80px;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 30% 0%, #1a0505, #0a0a0a);
            z-index: -1;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
        }

        /* ===== NAVIGATION ===== */
        .nav {
            background: rgba(20, 20, 28, 0.9);
            backdrop-filter: blur(16px);
            border-radius: 50px;
            padding: 8px 18px;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(255, 68, 68, 0.2);
        }

        .logo {
            font-size: 1.2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #ff5555);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .nav-links {
            display: flex;
            gap: 16px;
        }

        .nav-links a {
            color: #aaa;
            text-decoration: none;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .nav-links a:hover {
            color: #ff5555;
        }

        /* ===== CARDS ===== */
        .card {
            background: rgba(18, 18, 24, 0.85);
            backdrop-filter: blur(12px);
            border-radius: 28px;
            padding: 20px 18px;
            margin-bottom: 14px;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }

        .header {
            text-align: center;
            margin-bottom: 22px;
        }

        .header h1 {
            font-size: 1.8rem;
            font-weight: 800;
            background: linear-gradient(135deg, #ffffff, #ff5555);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .header p {
            color: #888;
            font-size: 0.7rem;
            margin-top: 4px;
        }

        .badge {
            background: rgba(255, 68, 68, 0.15);
            border: 1px solid rgba(255, 68, 68, 0.3);
            display: inline-block;
            padding: 4px 14px;
            border-radius: 40px;
            margin-top: 10px;
            font-size: 0.65rem;
            font-weight: 600;
            color: #ff6666;
        }

        .live-counter {
            background: rgba(255, 68, 68, 0.1);
            border-radius: 30px;
            padding: 6px 12px;
            margin-top: 12px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.7rem;
            color: #ff8888;
        }
        .live-dot {
            width: 8px;
            height: 8px;
            background: #ff4444;
            border-radius: 50%;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(1.2); }
            100% { opacity: 1; transform: scale(1); }
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            color: #bbb;
            font-weight: 500;
            margin-bottom: 6px;
            font-size: 0.75rem;
            display: block;
        }

        .uid-input {
            width: 100%;
            padding: 14px;
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 60px;
            font-size: 0.95rem;
            color: white;
            text-align: center;
        }

        .uid-input:focus {
            outline: none;
            border-color: #ff4444;
        }

        .btn-start {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff4444, #cc0000);
            border: none;
            border-radius: 60px;
            font-size: 0.95rem;
            font-weight: 700;
            color: white;
            cursor: pointer;
            margin-top: 6px;
        }

        .section-title {
            font-size: 1.1rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 16px;
            color: #fff;
        }

        .step-item {
            margin-bottom: 16px;
        }

        .step-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 8px;
        }

        .step-circle {
            width: 32px;
            height: 32px;
            background: #ff4444;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 0.9rem;
            color: white;
            flex-shrink: 0;
        }

        .step-title {
            font-weight: 600;
            color: #fff;
            font-size: 0.9rem;
        }

        .step-desc {
            color: #aaa;
            font-size: 0.7rem;
            margin-left: 44px;
            margin-bottom: 8px;
        }

        .step-ad {
            margin-top: 10px;
            margin-left: 0;
            width: 100%;
            overflow-x: auto;
        }

        .token-box {
            background: linear-gradient(135deg, #1a1a24, #0f0f15);
            border-radius: 24px;
            padding: 16px;
            text-align: center;
            margin: 14px 0;
        }

        .token-label {
            font-size: 0.65rem;
            color: #ff8888;
        }

        .token-code {
            font-size: 1.3rem;
            font-weight: 800;
            font-family: monospace;
            color: #ff6666;
            margin: 6px 0;
        }

        .send-hint {
            background: rgba(255, 68, 68, 0.08);
            border-radius: 16px;
            padding: 10px;
            margin-top: 12px;
            text-align: center;
            font-size: 0.65rem;
            color: #aaa;
        }
        .send-hint span {
            color: #ff8888;
        }

        .stats-row {
            display: flex;
            gap: 12px;
            margin: 14px 0;
        }

        .stat-card {
            flex: 1;
            background: rgba(0, 0, 0, 0.4);
            border-radius: 20px;
            padding: 12px;
            text-align: center;
        }

        .stat-number {
            font-size: 1.4rem;
            font-weight: 800;
            color: white;
        }

        .stat-label {
            font-size: 0.6rem;
            color: #888;
        }

        .ad-container {
            margin: 14px 0;
            text-align: center;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 20px;
            padding: 8px;
            overflow-x: auto;
        }

        .ad-label {
            font-size: 0.5rem;
            color: #555;
            margin-bottom: 6px;
        }

        .scroll-top {
            position: fixed;
            bottom: 70px;
            right: 15px;
            width: 42px;
            height: 42px;
            background: #ff4444;
            border-radius: 50%;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 999;
            box-shadow: 0 2px 12px rgba(255,68,68,0.4);
            border: none;
            font-size: 1.2rem;
        }

        .sticky-ad {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(10, 10, 15, 0.98);
            backdrop-filter: blur(16px);
            text-align: center;
            padding: 6px;
            z-index: 1000;
            border-top: 1px solid rgba(255, 68, 68, 0.3);
        }

        .footer {
            text-align: center;
            color: #555;
            font-size: 0.55rem;
            margin-top: 12px;
            padding-top: 10px;
            border-top: 1px solid rgba(255,255,255,0.05);
        }

        .social-wrap {
            margin-bottom: 14px;
        }

        @media (max-width: 480px) {
            body {
                padding: 10px;
                padding-bottom: 75px;
            }
            .card {
                padding: 16px 14px;
            }
            .header h1 {
                font-size: 1.6rem;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="nav">
        <div class="logo">H2B ABBAS</div>
        <div class="nav-links">
            <a href="index.php">HOME</a>
            <a href="about.php">ABOUT</a>
            <a href="contact.php">CONTACT</a>
        </div>
    </div>

    <div class="social-wrap">
        <?php include 'socialbar.php'; ?>
    </div>

    <div class="card">
        <div class="header">
            <h1>H2B ABBAS</h1>
            <p>Freefire Pro Player • Full Stack Developer</p>
            <div class="badge">🎮 500+ PLAYERS WAITING</div>
            <div class="live-counter">
                <div class="live-dot"></div>
                🔥 <?php echo $count_today; ?> players today
            </div>
        </div>

        <form method="GET" action="click_system.php">
            <div class="form-group">
                <label>🔫 FREEFIRE UID</label>
                <input type="text" class="uid-input" name="uid" placeholder="Enter 6-10 digit UID" maxlength="10" autocomplete="off" required>
            </div>
            <button type="submit" class="btn-start">▶ START 10-CLICK SYSTEM</button>
        </form>
    </div>

    <div class="card">
        <div class="section-title">⚡ HOW IT WORKS ⚡</div>

        <div class="step-item">
            <div class="step-header">
                <div class="step-circle">1</div>
                <div class="step-title">Enter UID</div>
            </div>
            <div class="step-desc">Enter your Freefire UID in the form above</div>
            <div class="step-ad">
                <div class="ad-label">ADVERTISEMENT</div>
                <script>atOptions={'key':'60af30741893b080cce19659c17e0662','format':'iframe','height':250,'width':300,'params':{}};</script>
                <script src="https://www.highperformanceformat.com/60af30741893b080cce19659c17e0662/invoke.js"></script>
            </div>
        </div>

        <div class="step-item">
            <div class="step-header">
                <div class="step-circle">2</div>
                <div class="step-title">10 Clicks</div>
            </div>
            <div class="step-desc">Complete 10 Adsterra smartlinks (safe ads)</div>
            <div class="step-ad">
                <div class="ad-label">ADVERTISEMENT</div>
                <script>atOptions={'key':'60af30741893b080cce19659c17e0662','format':'iframe','height':250,'width':300,'params':{}};</script>
                <script src="https://www.highperformanceformat.com/60af30741893b080cce19659c17e0662/invoke.js"></script>
            </div>
        </div>

        <div class="step-item">
            <div class="step-header">
                <div class="step-circle">3</div>
                <div class="step-title">Get Token & Play</div>
            </div>
            <div class="step-desc">Download file → Copy token → Send to H2B Abbas</div>
            <div class="step-ad">
                <div class="ad-label">ADVERTISEMENT</div>
                <script>atOptions={'key':'60af30741893b080cce19659c17e0662','format':'iframe','height':250,'width':300,'params':{}};</script>
                <script src="https://www.highperformanceformat.com/60af30741893b080cce19659c17e0662/invoke.js"></script>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="token-box">
            <div class="token-label">✦ YOUR TOKEN ✦</div>
            <div class="token-code">H2B-XXXXXX</div>
            <div style="font-size:0.6rem; color:#666;">1 Token = 1 Game with Abbas 🔥</div>
        </div>

        <div class="send-hint">
            📤 <span>How to send token?</span> → Copy token → WhatsApp/Telegram → Send to <strong>H2B Abbas</strong>
        </div>

        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-number">500+</div>
                <div class="stat-label">PLAYERS</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">10</div>
                <div class="stat-label">CLICKS = GAME</div>
            </div>
        </div>

        <div class="ad-container">
            <div class="ad-label">ADVERTISEMENT</div>
            <script>atOptions={'key':'60af30741893b080cce19659c17e0662','format':'iframe','height':250,'width':300,'params':{}};</script>
            <script src="https://www.highperformanceformat.com/60af30741893b080cce19659c17e0662/invoke.js"></script>
        </div>
    </div>

    <div class="footer">
        <p>© 2026 H2B Gaming | 10 Clicks = 1 Download = 1 Game</p>
        <p>💬 WhatsApp/Telegram: H2B Abbas | 1 Token = 1 Game</p>
    </div>
</div>

<button class="scroll-top" id="scrollTopBtn" onclick="window.scrollTo({top:0,behavior:'smooth'})">↑</button>

<div class="sticky-ad">
    <div class="ad-label">ADVERTISEMENT</div>
    <script>atOptions={'key':'1da28bc6cdef5f5056111a3524f2de3d','format':'iframe','height':50,'width':320,'params':{}};</script>
    <script src="https://www.highperformanceformat.com/1da28bc6cdef5f5056111a3524f2de3d/invoke.js"></script>
</div>

<script>
    window.onscroll = function() {
        const btn = document.getElementById('scrollTopBtn');
        if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
            btn.style.display = 'flex';
        } else {
            btn.style.display = 'none';
        }
    };
</script>

</body>
</html>