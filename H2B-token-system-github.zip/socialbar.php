<div class="social-bar-container" style="text-align: center; margin: 10px 0;">
    add your social link 