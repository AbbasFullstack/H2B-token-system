<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - H2B Abbas</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%);
            font-family: 'Poppins', 'Segoe UI', sans-serif;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        /* Navigation */
        .nav {
            background: rgba(0,0,0,0.8);
            border-radius: 50px;
            padding: 15px 25px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            border: 1px solid #00ff41;
        }
        .logo {
            color: #00ff41;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: 0.3s;
        }
        .nav-links a:hover {
            color: #00ff41;
        }
        /* Card */
        .card {
            background: rgba(0,0,0,0.7);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid #00ff41;
            margin-bottom: 20px;
        }
        .card h2 {
            color: #00ff41;
            margin-bottom: 20px;
            border-left: 3px solid #00ff41;
            padding-left: 15px;
        }
        .card p {
            color: #ccc;
            line-height: 1.6;
            margin-bottom: 15px;
        }
        .highlight {
            color: #00ff41;
            font-weight: bold;
        }
        .stats-box {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        .stat-item {
            background: #0a0a0a;
            padding: 15px;
            border-radius: 15px;
            text-align: center;
            border: 1px solid #333;
        }
        .stat-number {
            font-size: 2rem;
            color: #00ff41;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            color: #666;
            margin-top: 30px;
            font-size: 0.8rem;
        }
        @media (max-width: 600px) {
            .nav {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="nav">
        <div class="logo">🔥 H2B ABBAS</div>
        <div class="nav-links">
            <a href="index.php">🏠 Home</a>
            <a href="about.php">📖 About</a>
            <a href="contact.php">📞 Contact</a>
        </div>
    </div>

    <div class="card">
        <h2>📖 About H2B Abbas</h2>
        <p>Assalamu Alaikum! Main <span class="highlight">Abbas Hussain</span>, 16 saal ka <span class="highlight">Full-Stack Web Developer</span> aur <span class="highlight">Freefire Pro Player</span> hoon.</p>
        <p>Mujhe gaming aur coding dono se bohot pyaar hai. Maine yeh website banayi taki mere 500+ players ke saath systemically khel saku.</p>
        <p>Meri IDs:</p>
        <ul style="color:#ccc; margin-left: 20px; margin-top: 10px;">
            <li>🎮 H2B Blaster</li>
            <li>🎮 H2B ExtRix</li>
            <li>🎮 H2B Abbas</li>
        </ul>
    </div>

    <div class="card">
        <h2>🏆 My Achievements</h2>
        <div class="stats-box">
            <div class="stat-item">
                <div class="stat-number">500+</div>
                <div>Players Waiting</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">16</div>
                <div>Years Old</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">Full-Stack</div>
                <div>Developer</div>
            </div>
        </div>
    </div>

    <div class="card">
        <h2>💡 Why This System?</h2>
        <p>Mere paas 500+ players hain jo mere saath khelna chahte hain. Mujhe confuse na hona pada isliye maine yeh <span class="highlight">Token-based System</span> banaya.</p>
        <p>Jo player token lega, woh serious hoga. Is tarah sirf genuine players ke saath hi game khelta hoon.</p>
    </div>

    <div class="footer">
        <p>© 2026 H2B Gaming | Freefire Pro Player & Developer</p>
    </div>
</div>
</body>
</html>