<?php
session_start();
require_once 'db.php';

// Function to get device fingerprint
function getDeviceFingerprint() {
    $fingerprint = '';
    $fingerprint .= $_SERVER['HTTP_USER_AGENT'] ?? '';
    $fingerprint .= $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    $fingerprint .= $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
    return md5($fingerprint);
}

// Get player's IP
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'];
}

$uid = $_GET['uid'] ?? $_SESSION['click_uid'] ?? '';
$message = '';
$token = '';
$show_token = false;

if (empty($uid)) {
    $message = "No UID provided. Please go back and complete the 10 clicks first.";
} else {
    $ip = getClientIP();
    $fingerprint = getDeviceFingerprint();
    
    // Check if already claimed in last 24 hours
    $check = $conn->prepare("SELECT * FROM claimed_tokens WHERE (uid = ? OR ip_address = ? OR device_fingerprint = ?) AND claimed_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)");
    $check->bind_param("sss", $uid, $ip, $fingerprint);
    $check->execute();
    $result = $check->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $message = "❌ Already claimed! You already got a token in the last 24 hours.\n";
        $message .= "Your token was: " . $row['token'] . "\n";
        $message .= "Please wait 24 hours before claiming another token.";
        $show_token = false;
    } else {
        // Generate new token
        $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
        $token = 'H2B-';
        for ($i = 0; $i < 12; $i++) {
            $token .= $characters[rand(0, strlen($characters) - 1)];
        }
        
        // Save to database
        $stmt = $conn->prepare("INSERT INTO claimed_tokens (uid, ip_address, device_fingerprint, token) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $uid, $ip, $fingerprint, $token);
        
        if ($stmt->execute()) {
            $message = "✅ Here is your unique token!";
            $show_token = true;
        } else {
            $message = "❌ Error saving token. Please try again!";
            $show_token = false;
        }
        $stmt->close();
    }
    $check->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>H2B Abbas - Get Your Token</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 100%);font-family:'Poppins',monospace;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px;}
        .card{background:rgba(0,0,0,0.75);backdrop-filter:blur(10px);border-radius:30px;padding:40px;border:2px solid #00ff41;box-shadow:0 0 30px rgba(0,255,65,0.3);max-width:500px;width:100%;text-align:center;}
        h2{color:#00ff41;margin-bottom:20px;}
        .token{font-size:28px;font-weight:bold;background:#000;padding:20px;border-radius:15px;margin:20px 0;letter-spacing:2px;word-break:break-all;color:#00ff41;}
        .message{padding:15px;border-radius:10px;margin-bottom:20px;white-space:pre-line;}
        .success{background:#00ff4122;border:1px solid #00ff41;color:#00ff41;}
        .error{background:#ff333322;border:1px solid #ff3333;color:#ff6666;}
        button{background:#00ff41;color:#000;border:none;padding:12px 25px;font-size:16px;border-radius:10px;cursor:pointer;margin-top:10px;}
        button:hover{background:#00cc33;}
        .note{font-size:12px;color:#888;margin-top:20px;}
        .home-btn{background:#ff5500;margin-top:15px;}
        .home-btn:hover{background:#ff7700;}
    </style>
</head>
<body>
<div class="card">
    <h2>🎮 GET YOUR TOKEN 🎮</h2>
    
    <?php if ($message): ?>
        <div class="message <?php echo $show_token ? 'success' : 'error'; ?>">
            <?php echo nl2br(htmlspecialchars($message)); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($show_token && $token): ?>
        <div class="token" id="tokenValue"><?php echo $token; ?></div>
        <button onclick="copyToken()">📋 COPY TOKEN</button>
        <p class="note">⚠️ Copy this token and send to Abbas on WhatsApp/Telegram<br>
        Token valid for 24 hours | 1 token = 1 game</p>
    <?php endif; ?>
    
    <button class="home-btn" onclick="window.location.href='index.php'">🏠 Back to Home</button>
</div>

<script>
function copyToken() {
    const token = document.getElementById('tokenValue').innerText;
    navigator.clipboard.writeText(token).then(() => {
        alert('✅ Token copied! Ab Abbas ko bhejo 🎯');
    }).catch(() => {
        alert('Manual copy karo: ' + token);
    });
}
</script>
</body>
</html>