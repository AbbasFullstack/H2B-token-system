<?php
require_once 'db.php';
header('Content-Type: application/json');

$token = $_GET['token'] ?? '';

if (empty($token)) {
    echo json_encode(['status' => 'invalid', 'message' => 'No token provided']);
    exit;
}

$stmt = $conn->prepare("SELECT uid, token_generated_at, token_used FROM players WHERE token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'invalid', 'message' => 'Token not found']);
    exit;
}

$row = $result->fetch_assoc();

if ($row['token_used'] == 1) {
    echo json_encode(['status' => 'invalid', 'message' => 'Token already used']);
    exit;
}

echo json_encode([
    'status' => 'valid',
    'uid' => $row['uid'],
    'generated_at' => $row['token_generated_at']
]);
?>