<?php
session_start();

$correct_password = "Abbas777$";

if (!isset($_SESSION['logged_in']) && isset($_POST['password'])) {
    if ($_POST['password'] === $correct_password) {
        $_SESSION['logged_in'] = true;
    }
}

if (!isset($_SESSION['logged_in'])) {
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>H2B Dashboard - Login</title>
        <style>
            body{background:#0a0a0a;font-family:Arial;display:flex;justify-content:center;align-items:center;height:100vh;}
            .login-box{background:#111;padding:40px;border-radius:20px;border:2px solid #ff0000;text-align:center;}
            h2{color:#ff0000;}
            input{padding:12px;width:200px;background:#222;border:1px solid #ff0000;color:#ff0000;border-radius:10px;margin:10px;}
            button{background:#ff0000;color:#fff;padding:10px 30px;border:none;border-radius:10px;cursor:pointer;}
        </style>
    </head>
    <body>
        <div class="login-box">
            <h2>🔐 H2B Dashboard</h2>
            <form method="POST">
                <input type="password" name="password" placeholder="Enter Password">
                <br>
                <button type="submit">Login</button>
            </form>
        </div>
    </body>
    </html>';
    exit;
}

require_once 'db.php';

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: dashboard.php");
    exit;
}

// Get statistics
$total_players = $conn->query("SELECT COUNT(DISTINCT uid) as count FROM players")->fetch_assoc()['count'];
$total_tokens = $conn->query("SELECT COUNT(*) as count FROM players")->fetch_assoc()['count'];
$tokens_used = $conn->query("SELECT COUNT(*) as count FROM players WHERE token_used = 1")->fetch_assoc()['count'];
$games_played = $conn->query("SELECT COUNT(*) as count FROM players WHERE game_played = 1")->fetch_assoc()['count'];
$today_tokens = $conn->query("SELECT COUNT(*) as count FROM players WHERE DATE(token_generated_at) = CURDATE()")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>H2B Abbas - Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:linear-gradient(135deg,#0a0a0a 0%,#1a0000 100%);font-family:"Poppins",monospace;padding:20px;color:#fff;}
        .container{max-width:1400px;margin:0 auto;}
        h1{color:#ff3333;border-left:4px solid #ff3333;padding-left:20px;margin-bottom:30px;}
        .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:20px;margin-bottom:40px;}
        .stat-card{background:rgba(0,0,0,0.7);border:1px solid #ff3333;border-radius:15px;padding:20px;text-align:center;}
        .stat-number{font-size:2.5rem;font-weight:bold;color:#ff3333;}
        .stat-label{color:#aaa;margin-top:10px;}
        .table-container{background:rgba(0,0,0,0.7);border-radius:15px;padding:20px;overflow-x:auto;}
        table{width:100%;border-collapse:collapse;}
        th,td{padding:12px;text-align:left;border-bottom:1px solid #333;}
        th{color:#ff3333;}
        .token-used{color:#00ff00;}
        .token-pending{color:#ffaa00;}
        .game-done{color:#00ff00;}
        .logout-btn{background:#ff3333;color:white;padding:10px 20px;border:none;border-radius:10px;cursor:pointer;margin-bottom:20px;}
        .refresh-btn{background:#ff3333;color:#fff;padding:10px 20px;border:none;border-radius:10px;cursor:pointer;margin-left:10px;}
        .verify-box{background:#1a0000;padding:20px;border-radius:15px;margin-top:30px;border:1px solid #ff3333;}
        .verify-input{padding:10px;width:300px;background:#222;border:1px solid #ff3333;color:#ff3333;border-radius:10px;}
        .verify-result{margin-top:10px;padding:10px;border-radius:10px;}
    </style>
</head>
<body>
<div class="container">
    <div style="display:flex;justify-content:space-between;align-items:center;">
        <h1>🔥 H2B ABBAS - ADMIN DASHBOARD 🔥</h1>
        <div>
            <button class="refresh-btn" onclick="location.reload()">🔄 Refresh</button>
            <button class="logout-btn" onclick="location.href='?logout=1'">🚪 Logout</button>
        </div>
    </div>

    <div class="stats">
        <div class="stat-card"><div class="stat-number"><?php echo $total_players; ?></div><div class="stat-label">👥 Total Players</div></div>
        <div class="stat-card"><div class="stat-number"><?php echo $total_tokens; ?></div><div class="stat-label">🎫 Total Tokens</div></div>
        <div class="stat-card"><div class="stat-number"><?php echo $tokens_used; ?></div><div class="stat-label">✅ Tokens Used</div></div>
        <div class="stat-card"><div class="stat-number"><?php echo $games_played; ?></div><div class="stat-label">🎮 Games Played</div></div>
        <div class="stat-card"><div class="stat-number"><?php echo $today_tokens; ?></div><div class="stat-label">📅 Today\'s Tokens</div></div>
    </div>

    <div class="verify-box">
        <h3 style="color:#ff3333">🔍 Verify Token</h3>
        <input type="text" id="tokenToVerify" class="verify-input" placeholder="Enter Token (e.g., H2B-XXXX)">
        <button onclick="verifyToken()" style="background:#ff3333; color:#fff; padding:10px 20px; border:none; border-radius:10px; margin-left:10px;">Verify</button>
        <div id="verifyResult" class="verify-result"></div>
    </div>

    <div class="table-container">
        <h3 style="color:#ff3333; margin-bottom:15px;">📋 Recent Players & Tokens</h3>
        <table>
            <thead>
                <tr><th>ID</th><th>UID</th><th>Token</th><th>Generated At</th><th>Token Used</th><th>Game Played</th><th>IP Address</th></tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM players ORDER BY id DESC LIMIT 50");
                while ($row = $result->fetch_assoc()) {
                    $token_status = $row['token_used'] ? '<span class="token-used">✅ Used</span>' : '<span class="token-pending">⏳ Pending</span>';
                    $game_status = $row['game_played'] ? '<span class="game-done">🎮 Done</span>' : '❌ Not Yet';
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['uid']}</td>
                        <td style='font-family:monospace'>{$row['token']}</td>
                        <td>{$row['token_generated_at']}</td>
                        <td>{$token_status}</td>
                        <td>{$game_status}</td>
                        <td>{$row['ip_address']}</td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function verifyToken() {
    const token = document.getElementById('tokenToVerify').value.trim();
    if (!token) { alert('Enter a token!'); return; }
    
    fetch(`verify_token.php?token=${encodeURIComponent(token)}`)
        .then(response => response.json())
        .then(data => {
            const resultDiv = document.getElementById('verifyResult');
            if (data.status === 'valid') {
                resultDiv.innerHTML = `<div style="background:#00ff4122; border:1px solid #00ff41; padding:10px; border-radius:10px;">
                    ✅ Token VALID!<br>
                    UID: ${data.uid}<br>
                    Generated: ${data.generated_at}<br>
                    <button onclick="markUsed('${token}')" style="background:#ff3333; color:#fff; padding:5px 15px; margin-top:10px; border:none; border-radius:5px; cursor:pointer;">Mark as Used</button>
                </div>`;
            } else {
                resultDiv.innerHTML = `<div style="background:#ff333322; border:1px solid #ff3333; padding:10px; border-radius:10px;">
                    ❌ ${data.message}
                </div>`;
            }
        });
}

function markUsed(token) {
    fetch(`mark_used.php?token=${encodeURIComponent(token)}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('Token marked as used!');
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        });
}
</script>
</body>
</html>