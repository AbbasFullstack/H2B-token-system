<?php
require_once 'db.php';
header('Content-Type: application/json');

$token = $_GET['token'] ?? '';

if (empty($token)) {
    echo json_encode(['status' => 'error', 'message' => 'No token provided']);
    exit;
}

$stmt = $conn->prepare("UPDATE players SET token_used = 1 WHERE token = ? AND token_used = 0");
$stmt->bind_param("s", $token);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(['status' => 'success', 'message' => 'Token marked as used']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Token already used or not found']);
}
?>