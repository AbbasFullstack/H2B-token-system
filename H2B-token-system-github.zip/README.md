# 🔥 H2B Gaming Token System

Complete Freefire token system with 10-click Adsterra integration, PPD file download, and admin dashboard.

## Features
- 10-Click System (Adsterra Smartlinks)
- PPD File Download
- Token Security (IP + Device Fingerprint)
- Admin Dashboard
- Mobile Responsive

## Tech Stack
- PHP, MySQL, JavaScript, HTML/CSS
- Adsterra API
- File-Upload PPD

## Setup
1. Upload to PHP server (InfinityFree / Hostinger)
2. Create MySQL database
3. Rename `db-sample.php` to `db.php` and add your credentials
4. Login to dashboard: Password `Abbas777$`